# AlgoTrading
Investigating technical trading methods

# Dev Environment
```cd <where you want the repo> ```

```git clone git@github.com:artinusai/AlgoTrading.git```

```cd <where you want the repo>/AlgoTrading/artinus_algotradin```

The pip install ```-e ``` command is used to install a package in editable mode, also known as "editable install" or "development mode." When you install a package using pip install, it typically copies the package's files to your Python environment, and any changes you make to the package afterward won't be reflected unless you reinstall it. 

if you have no intention of modifying the repo ommit the ```-e``` from the folowing command.

``` pip install -e .```

# Usage

```
from artinus_algotrading import signals, backtesting

values = np.arange(20)**2
lines = [[2,4], [10,15]]

lines = signals.slope_filter(values, lines, filter_type = 'higher')
signals.plot_single_value(values, lines)
```