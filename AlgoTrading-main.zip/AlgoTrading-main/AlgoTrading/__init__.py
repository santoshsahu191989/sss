from . import backtesting
from . import signals
import david_strat