import numpy as np
import os
from datetime import date, datetime, timedelta
import pandas as pd
from datetime import datetime as dt
import json
import itertools
import ast
import dateutil.relativedelta as relativedelta
import dateutil.rrule as rrule
from dateutil.parser import isoparse
import copy

# from artinus_algotrading.backtesting import trail_stop
# from artinus_algotrading.signals import rsi
# from artinus_algotrading.signals import *


class PatternHandler():
    def __init__(self, general_path, pattern_path):
        # self.general_path = general_path
        # self.pattern_path = pattern_path
        
        self.params_by_name = {}
        
        with open(general_path) as f:
            self.general_settings = json.load(f)
    
        with open(pattern_path) as f:
            # pattern = f.read()
            self.pattern = json.load(f)
        self.pattern_str = str(self.pattern)
        self.settings = {'values_settings':{},'lines_settings':{},'trade_settings':{}}
        
    def replace_param(self, arg, value, setting_str):
        if isinstance(value, str):
            setting_str = setting_str.replace(f"'<{arg}>'",f"'{value}'")
        else:
            setting_str = setting_str.replace(f"'<{arg}>'",f'{value}')
            
            
        return setting_str
    
    def replace_name(self, name, value, setting_str):
        setting_str = setting_str.replace(f"'{name}'",f"'{value}'")
        return setting_str
    
    def param_parse(self, settings, name = None):
        
        
        if  isinstance(settings, str):
            name = settings
            settings = self.pattern['lines_settings'][name]
            
        if name is None:
            return set()
        if name in self.params_by_name and name is not None:
            return self.params_by_name[name]
        
        setting_og = str(settings)
        params = set()
        
        for param, values in self.general_settings['pattern'].items():
            setting_new = self.replace_param(param, values[0],setting_og)

            if setting_og!=setting_new:
                params.add(param)
        
        return params
            
    def recursive_line_parse(self, line_setting, name = None):
        params = set()
        if isinstance(line_setting, str):
            name = line_setting
            
        if name is not None:
            if name in self.pattern['values_settings']:
                line_setting = self.pattern['values_settings'][name]
                setting_type = 'values_settings'
            elif name in self.pattern['lines_settings']:
                line_setting = self.pattern['lines_settings'][name]
                setting_type = 'lines_settings'
            elif name in self.pattern['trade_settings']:
                line_setting = self.pattern['trade_settings'][name]
                setting_type = 'trade_settings'
            
        if 'values' in line_setting:
            params |= self.recursive_line_parse(line_setting['values'])


        if 'trail_stop' in line_setting:
            params |= self.recursive_line_parse(line_setting['trail_stop']['lines'])


        if 'lines' in line_setting:
            params |= self.recursive_line_parse(line_setting['lines'])

            
        elif 'line_point_filter' in line_setting:

            params |= self.recursive_line_parse(line_setting['line_point_filter']['left'])
            params |= self.recursive_line_parse(line_setting['line_point_filter']['right'])

        params |= self.param_parse(line_setting, name)
            
        if name is not None:
            self.params_by_name[name] = params
        
        
        return params
    
    def name_formatter(self, name):
        if name in self.params_by_name and len(self.params_by_name[name]) >= 1:
            name_new = name+'('
            for param in self.params_by_name[name]:
                name_new += f"{param}:'<{param}>',"

            name_new = name_new[:-1]+')'
            self.pattern_str = self.pattern_str.replace(f"'{name}'",f"'{name_new}'")

  
    def get_start_end_symbol_combos(self):
        dates = []
        before=isoparse(self.general_settings['start'])#datetime.datetime(2015,1,1)
        after=isoparse(self.general_settings['end']) #datetime.datetime(2022,2,1)

        rr = rrule.rrule(rrule.WEEKLY,byweekday=relativedelta.MO,dtstart=before)
        for monday in rr.between(before,after,inc=True):
            monday+= timedelta(minutes=1)
            friday = monday+ timedelta(days=5)

            monday = monday.isoformat()
            friday = friday.isoformat()
            
            dates.append((monday, friday))
        settings_list = []
        # display(dates)
        self.settings['data_path'] = self.general_settings['data_path']
        for monday, friday in dates:
            for symbol in self.general_settings['symbols']:
                temp_settings = copy.deepcopy(self.settings)
                temp_settings['start'], temp_settings['end'], temp_settings['symbol'] = monday, friday, symbol
                settings_list.append(temp_settings)
                
        return settings_list
    
    def create_settings(self):
        param_ordered = []
        param_combos = []
        for param in self.general_settings['pattern']:
            param_ordered.append(param)
            param_combos.append(self.general_settings['pattern'][param])
            
        param_combos = itertools.product(*param_combos)
        
        for param_combo in param_combos:
            pattern_replaced = self.pattern_str
            for i in range(0,len(param_ordered)):
                pattern_replaced = self.replace_param(param_ordered[i], param_combo[i], pattern_replaced)
            
            pattern_replaced = ast.literal_eval(pattern_replaced)
            for setting in self.settings:
                self.settings[setting]|= pattern_replaced[setting]
            # display()
    
    def run(self):
        for name in self.pattern['trade_settings']:
            self.recursive_line_parse(name)
        
        for setting in ['values_settings', 'lines_settings', 'trade_settings']:
            for name in self.pattern[setting]:
                self.name_formatter(name)
                
        
        self.create_settings()
            
            
            
        settings_list = self.get_start_end_symbol_combos()
        
        
        return settings_list
        
    def trade_parse(self, trade_settings):
        for trade_name, trade_setting in self.general_settings['trade_settings']:
            self.recursive_line_parse(trade_setting['trail_stop']['lines'])