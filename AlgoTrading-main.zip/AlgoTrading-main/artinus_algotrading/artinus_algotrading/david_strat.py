import numpy as np
from .signals import get_price, get_price_rsi, extrema_lines, slope_filter, concativity_filter, line_point_filter, timeframe_multiplier, timeframe_divider, , , 
from .backtesting import trail_stop


class StrategyParser():
    def __init__(self, start, end, lines_settings, values_settings, verbose = False):
        '''
        timeframe(int): how long in minutes a candle period is
        '''
        self.lines_settings = lines_settings
        self.values_settings = values_settings
        self.verbose = verbose
        
        self.values_by_name = {}
        self.lines_by_name = {}
        
        self.start = start
        self.end = end
        
        
        self.org = "Artinus"
        url = "https://eastus-1.azure.cloud2.influxdata.com"
        token = "l7mZ63vVVzgUKP2z6_XMnZWKKJ4VNEeA6hSMPbqj_-z2l86OpSV8RA9EMzwoTPZSgg9KZzA8R6AkwztiBHgT6A=="

        self.client = influxdb_client.InfluxDBClient(url=url, token=token, org=self.org)
        self.bucket = 'DukascopyTest'
        
        
        
    def get_values(self,name, value_type,**settings):
        # {'value_type':'price','period':5, 'measurement': 'bid_low'}
        print(settings)
        if value_type == 'price':
            self.values_by_name[name] = get_price(self.client, self.org, self.bucket, self.start, self.end,**settings)
        if value_type == 'rsi':
            self.values_by_name[name] = get_price_rsi(self.client, self.org, self.bucket, self.start, self.end,**settings)[1]
        print(name, settings)
        
        
    def recursive_line(self, line_setting = None, name = None):
        '''
        
        line_setting: can be a dict that defines lines or a string of the lines name
        '''
        _id = ''
        
        if isinstance(line_setting, str):
            # print(line_setting)
            name = line_setting
            line_setting = self.lines_settings[line_setting]
        
        
        if name is not None and name in self.lines_by_name:
            if self.verbose:
                print(f'PRECOMPUTED:{name}')
            return self.lines_by_name[name], line_setting
        if self.verbose:
                print(f'START:{name}')
        
        if 'line_point_filter' in line_setting:
            if self.verbose:
                print('\tline_point_filter')
            
            
            
            left, line_setting_left = self.recursive_line(line_setting = line_setting['line_point_filter']['left'])
            right, line_setting_right = self.recursive_line(line_setting = line_setting['line_point_filter']['right'])
            
            
            lcm = np.lcm(line_setting_left['period'],line_setting_right['period'])
            
            left_multiplier = lcm//line_setting_right['period']
            right_multiplier = lcm//line_setting_left['period']

            left = timeframe_multiplier(left, left_multiplier)
            right = timeframe_multiplier(right, right_multiplier)
            
            if isinstance(line_setting['line_point_filter']['filter_type'], int):
                left, right = line_point_filter(left, 
                                                right, 
                                                filter_type = line_setting['line_point_filter']['filter_type'], 
                                                allowed_offset = line_setting['line_point_filter']['allowed_offset'])
                
            else:
                left, right = line_point_filter(left, 
                                                right, 
                                                filter_type = line_setting['line_point_filter']['filter_type'][1], 
                                                allowed_offset = line_setting['line_point_filter']['allowed_offset'][1])
                
                left, right = line_point_filter(left, 
                                                right, 
                                                filter_type = line_setting['line_point_filter']['filter_type'][0], 
                                                allowed_offset = line_setting['line_point_filter']['allowed_offset'][0])
                
                
                
            if line_setting['line_point_filter']['keep'] == 'right':
                lines = timeframe_divider(right, right_multiplier)
                line_setting['period'] = line_setting_right['period']
                # lines = right
                
            if line_setting['line_point_filter']['keep'] == 'left':
                lines = timeframe_divider(left, left_multiplier)
                line_setting['period'] = line_setting_left['period']
                # lines = left
            else:
                pass
                # Error
            
        
        if 'values' in line_setting:
            if self.verbose:
                print('\tvalues')
            values = self.values_by_name[line_setting['values']]
            line_setting['period'] = self.values_settings[line_setting['values']]['period']
            
        if 'lines' in line_setting:
            if self.verbose:
                print('\tlines')
            lines, old_line_setting= self.recursive_line(line_setting = line_setting['lines'])
            line_setting['period'] = old_line_setting['period']
            
        if 'extrema_lines' in line_setting:
            if self.verbose:
                print('\textrema_lines')
            lines = extrema_lines(values,**line_setting['extrema_lines'])
                
        if 'slope_filter' in line_setting:
            if self.verbose:
                print('\tslope_filter')
            lines = slope_filter(values, lines, **line_setting['slope_filter'])
            
        if 'concativity_filter' in line_setting:
            if self.verbose:
                print('\tconcativity_filter')
            lines = concativity_filter(values, lines, **line_setting['concativity_filter'])
        
        if name is not None:
            self.lines_by_name[name] = lines
        if self.verbose:
            print(f'END:{name}')
        return lines, line_setting
    
    def run(self):
        for values_setting in self.values_settings:
            self.get_values(values_setting, **self.values_settings[values_setting])
            
        for name in self.lines_settings.keys():
            self.recursive_line(self.lines_settings[name], name)
            
    def plot(self, values_name, lines_name):
        values = self.values_by_name[values_name]
        lines = self.lines_by_name[lines_name]
        
        x_plot_lines = []
        y_plot_lines = []
        for line in lines:
            x_plot_lines += [line[0],line[1], None]
            y_plot_lines += [values[line[0]], values[line[1]], None]

        fig = go.Figure(
                data=[
                    go.Scattergl(
                        y=values, mode="markers+lines", name=values_name
                    ),
                    go.Scattergl(
                        x=x_plot_lines, y=y_plot_lines, mode="markers", name=lines_name+' markers'
                    ),
                    go.Scattergl(
                        x=x_plot_lines, y=y_plot_lines, mode="markers+lines", name=lines_name
                    ),
                    
                ],
            )
        fig.show()