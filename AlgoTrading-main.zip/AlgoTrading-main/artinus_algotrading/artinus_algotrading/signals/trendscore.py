import numpy as np


def get_trendscore(trend, time_start, time_stop, bid_type):
    df_fast = candlestickMovingAverage(time_start, time_stop, 13, bid_type)[81-13:].reset_index(drop=True)
    df_slow = candlestickMovingAverage(time_start, time_stop, 81, bid_type)

    df_diff = df_fast.price-df_slow.price
    df_diff = np.asarray(df_diff)
    df_diff = df_diff[1:]

    df_fast_slope=[]
    for i in range(1, len(df_fast)):
        df_fast_slope.append(df_fast.price[i]-df_fast.price[i-1]) 

    df_fast_slope = np.asarray(df_fast_slope)
    df_fast_slope_is_down = df_fast_slope < 0
    
    df_slow_slope=[]
    for i in range(1, len(df_slow)):
        df_slow_slope.append(df_slow.price[i]-df_slow.price[i-1]) 

    df_slow_slope = np.asarray(df_slow_slope)
    df_slow_slope_is_down = df_slow_slope < 0
   
    if trend == 'bearish':
        #Bearish
        df_TS_bear = (df_diff < 0) & df_fast_slope_is_down
        slow_start = []
        slow_end = []
        for i in range(1, len(df_TS_bear)):
            if df_TS_bear[i-1] and ~df_TS_bear[i]: #start
                slow_end.append(i-1)

            if ~df_TS_bear[i-1] and df_TS_bear[i]: #end
                slow_start.append(i-1)

        in_block = None
        bear_sum = []
        running_sum = 0

        length_box_list = []
        length_box = 0

        for idx, diff in enumerate(df_diff):
            if diff < 0 and df_TS_bear[idx]:
                in_block = True
                running_sum += 1
                bear_sum.append(running_sum)

                length_box += 1
                length_box_list.append(length_box)

            elif diff > 0:
                running_sum = 0
                length_box = 0
                bear_sum.append(running_sum)
                length_box_list.append(length_box)
            else:
                length_box += 1
                length_box_list.append(length_box)

                bear_sum.append(running_sum)
        bear_sum = np.asarray(bear_sum)   
        length_box_list = np.asarray(length_box_list)  
        trendscore = -(bear_sum * (bear_sum + 1)/2 + length_box_list)

        
    elif trend == 'bullish':
        #Bullish
        df_TS_bull = (df_diff > 0) & ~df_fast_slope_is_down
        slow_start = []
        slow_end = []
        for i in range(1, len(df_TS_bull)):
            if df_TS_bull[i-1] and ~df_TS_bull[i]: #start
                slow_end.append(i-1)

            if ~df_TS_bull[i-1] and df_TS_bull[i]: #end
                slow_start.append(i-1)

        in_block = None
        bull_sum = []
        running_sum = 0

        length_box_list = []
        length_box = 0

        for idx, diff in enumerate(df_diff):
            if diff > 0 and df_TS_bull[idx]:
                in_block = True
                running_sum += 1
                bull_sum.append(running_sum)

                length_box += 1
                length_box_list.append(length_box)

            elif diff < 0:
                running_sum = 0
                length_box = 0
                bull_sum.append(running_sum)
                length_box_list.append(length_box)
            else:
                length_box += 1
                length_box_list.append(length_box)

                bull_sum.append(running_sum)
        bull_sum = np.asarray(bull_sum)   
        length_box_list = np.asarray(length_box_list)  
        trendscore = (bull_sum * (bull_sum + 1)/2 + length_box_list)

    return trendscore