from scipy.signal import find_peaks
import numpy as np
import plotly.graph_objects as go
from .rsi import rsi

import influxdb_client
import os
import time
from influxdb_client import InfluxDBClient, Point, WritePrecision
import plotly.graph_objects as go

from artinus_algotrading.backtesting import trail_stop

from datetime import datetime
import pandas as pd

def candlestickData(client, org, bucket, range_start, range_stop, symbol, period, measurement):
    query_api = client.query_api()
    if measurement == "bid_open":
        aggfunc = "first"
    elif measurement == "bid_high":
        aggfunc = "max"
    elif measurement == "bid_low":
        aggfunc = "min"
    elif measurement == "bid_close":
        aggfunc = "last"

    if isinstance(period, int):
        period = f'{period}m'

    query = f"""
            import "date"
            from(bucket: "{bucket}")
            |> range(start: {range_start}, stop: {range_stop})
            |> filter(fn: (r) => r._measurement == "{measurement}")
            |> filter(fn: (r) => r.symbol == "{symbol}")
            |> pivot(rowKey:["_time"], columnKey: ["_field"], valueColumn: "_value")
            |> map(fn: (r) => ({{r with _time: date.add(d: -1s, to: r._time)}}))
            |> aggregateWindow(column: "price", every: {period}, fn: {aggfunc})
            """
    tables = query_api.query(query, org=org)
    df = query_api.query_data_frame(query, org=org)
    return df


def get_price(client, org, bucket, range_start, range_stop, symbol, period, measurement):
    price = candlestickData(client, org, bucket, range_start, range_stop, symbol, period, measurement)

    # TODO: instead of droping missing datapoints in price we should do linear interpolation
    price = price.dropna()
    return price['price'].to_numpy()


def get_price_rsi(client, org, bucket, range_start, range_stop, symbol, period, measurement, window_length=7):
    price = candlestickData(client, org, bucket, range_start, range_stop, symbol, period, measurement)

    # TODO: instead of droping missing datapoints in price we should do linear interpolation
    price = price.dropna()
    rsi_values = rsi(price, 'price', window_length)

    return price['price'].to_numpy(), rsi_values['rsi'].to_numpy()


def extrema_lines(values, filter_type='high', num_periods=20, height=None):
    '''
    Args:
        values (iterable). Could be price or RSI
        filter_type ("high" or "low"): is the high in higher high
        num_periods:
        height (int): Should only be used with rsi. 
            height of 30 and type2 = "low" will cut off all troughs above 30 
            height of 30 and type2 = "high" will cut off all peaks below 70 
    returns:
        list of index pairs
    '''

    if filter_type == 'low':
        if height is not None:
            height = -height
        values = -values

    if filter_type == 'high' and height is not None:
        height = 100 - height

    extrema_indicies, _ = find_peaks(values, height=height)
    extrema_values = values[extrema_indicies]
    if filter_type == 'low':
        values = -values

    lines = []
    for i in range(0, len(extrema_indicies) - 1):
        for j in range(i + 1, len(extrema_indicies)):
            if extrema_indicies[j] - extrema_indicies[i] < num_periods:
                lines.append((extrema_indicies[i], extrema_indicies[j]))
            else:
                break
    return lines


def slope_filter(values, lines, filter_type='higher'):
    ''' 
    Note: This is by far the most effecent to compute so should be applied before other filters
    Args:
        values (iterable). Could be price or RSI
        filter_type ('higher' or 'lower'): is the higher in higher high
        lines (list of lines): [(x0, x1)], ...]. x0 must be less then x1
    '''
    filtered_lines = []
    for line in lines:
        m = values[line[0]] - values[line[1]]

        if (filter_type == 'higher' and m > 0) or (filter_type == 'lower' and m < 0):
            filtered_lines.append(line)

    return filtered_lines


def concativity_filter(values, lines, filter_type="concave"):
    '''
    Args:
        values (iterable). Could be price or RSI
        lines list of lines aka two points: [[(x0), (x1)], ...]. x0 must be less then x1
        filter_type ("concave" or "convex"): any two points of x^2 would be concave and -x^2 would be convex
    returns:
        list of index pairs
    '''
    filtered_lines = []

    for line in lines:
        condition = True
        m = ((values[line[0]] - values[line[1]]) / (line[0] - line[1]))

        for i in range(line[0] + 1, line[1]):
            comparison_m = ((values[line[0]] - values[i]) / (line[0] - i))
            if (filter_type == "concave" and comparison_m > m) or (filter_type == "convex" and comparison_m < m):
                condition = False
                break

        if condition:
            filtered_lines.append(line)
    return filtered_lines


def line_point_filter(lines0, lines1, filter_type=0, allowed_offset=0):
    ''' 
    Note: O(n) i think?
    Args:
        lines0 and lines1 (list of lines): [(x0, x1)], ...]. x0 must be less then x1
        filter_type (0 or 1): 0 means the start points are compaired and 1 means the end points
        allowed_offset: [(x0, x1)], ...]. x0 must be less then x1
    '''

    # finds the maximum index if it is not provided

    max_index = 0
    for line in [*lines0, *lines1]:
        max_index = max(line[1] + 1, max_index)

    # sets all areas that are allowed_offset away from the point to 1
    truth_table0 = np.zeros(max_index)
    for line in lines0:
        start = max(0, line[filter_type] - allowed_offset)
        end = min(max_index, line[filter_type] + allowed_offset)
        truth_table0[start:end + 1] = 1

    truth_table1 = np.zeros(max_index)
    for line in lines1:
        start = max(0, line[filter_type] - allowed_offset)
        end = min(max_index - 1, line[filter_type] + allowed_offset)
        truth_table1[start:end + 1] = 1

    truth_table = truth_table0 * truth_table1

    filtered_lines0 = [line for line in lines0 if truth_table[line[filter_type]]]
    filtered_lines1 = [line for line in lines1 if truth_table[line[filter_type]]]

    return filtered_lines0, filtered_lines1


def timeframe_multiplier(lines, value=1):
    ''' 
    allows comparison between diffrent timeframes. 
    e.g. if you want to meaningfully compare 1m and 5m using the line_point_filter function you must 
    run this function point_multiplier(<lines 5m>, value = 5) 

    5min and 20min
    point_multiplier(<lines 20m>, value = 4) 

    Args:
        lines (list of lines): [(x0, x1)], ...]. x0 must be less then x1
        value (int): value to multipy lines by. 
    '''
    if value == 1:
        return lines

    return np.array(lines) * value


def timeframe_divider(lines, value=1):
    ''' 
    if you want to undo timeframe_multiplier.

    Note: this should only be run on lines that have been first run through point_multiplier and should have the same value arg

    Args:
        lines (list of lines): [(x0, x1)], ...]. x0 must be less then x1
        value (int): value to multipy lines by. 
    '''
    if value == 1:
        return lines
    return np.array(lines) // value


def plot_single_value(values, lines):
    '''
    Args:
        values (iterable). Could be price or RSI
        lines (list of lines): [(x0, x1)], ...]. x0 must be less then x1
    '''
    x_plot_lines = []
    y_plot_lines = []
    for line in lines:
        x_plot_lines += [line[0], line[1], None]
        y_plot_lines += [values[line[0]], values[line[1]], None]

    fig = go.Figure(
        data=[
            go.Scattergl(
                y=values, mode="markers+lines", name="values"
            ),
            go.Scattergl(
                x=x_plot_lines, y=y_plot_lines, mode="markers+lines", name="lines"
            ),
        ],
    )
    fig.show()


def plot_two_value(values0, lines0, values1, vlaues1):
    '''
    Args:
        values (iterable). Could be price or RSI
        lines (list of lines): [(x0, x1)], ...]. x0 must be less then x1
    '''
    x_plot_lines0 = []
    y_plot_lines0 = []
    for line in lines:
        x_plot_lines0 += [line[0], line[1], None]
        y_plot_lines0 += [values[line[0]], values[line[1]], None]

    x_plot_lines1 = []
    y_plot_lines1 = []
    for line in lines:
        x_plot_lines1 += [line[0], line[1], None]
        y_plot_lines1 += [values[line[0]], values[line[1]], None]

    fig = go.Figure(
        data=[
            go.Scattergl(
                y=values, mode="markers+lines", name="values"
            ),
            go.Scattergl(
                x=x_plot_lines, y=y_plot_lines, mode="markers+lines", name="lines"
            ),
        ],
    )
    fig.show()


def iso_to_unix(iso_date):
    # Parse the ISO date string into a datetime object
    date = datetime.fromisoformat(iso_date[0:19])

    # Convert the datetime object to a Unix timestamp
    unix_timestamp = date.timestamp()

    return int(unix_timestamp)


def get_price(data_path, start, end, symbol, period, measurement):
    # print(data_path, start, end, symbol, period, measurement)

    if isinstance(start, str):
        start = iso_to_unix(start)
    if isinstance(end, str):
        end = iso_to_unix(end)

    symbol = symbol.replace('/', '#')
    path = os.path.join(data_path, symbol)  # ,f"{start//1000}-{end//1000}-{name}.npy")
    file_paths = []
    for f in os.listdir(path):
        # print(f)
        len_start = len(str(end))
        len_end = len(str(end))
        # print(f)
        if int(f[:len_start]) >= start and int(f[len_start + 1:len_start + 1 + len_end]) <= end and measurement == f[-4 - len(measurement):-4]:
            file_paths.append(f)

    file_paths.sort()
    # print(start,end)
    # print(file_paths)
    arrays = [np.load(os.path.join(path, f)) for f in file_paths]

    if len(arrays) == 0:
        return[]

    # if period ==1:
    #     return arrays[0]
    # pad arr

    arr = np.concatenate(arrays)

    padding = period - (len(arr) % period)
    arr = np.pad(arr, (0, padding), mode='empty')

    # Reshape the array into a 2D array of shape (n, period)
    n = len(arr) // period
    arr = arr.reshape((n, period))

    if measurement == 'bid_high':
        arr = np.max(arr, axis=1)
    if measurement == 'bid_low':
        arr = np.min(arr, axis=1)

    if measurement == 'bid_close':
        arr = arr[:, -1].flatten()
    if measurement == 'bid_open':
        arr = arr[:, 1].flatten()
    return arr


def get_rsi(data_path, start, end, symbol, period, measurement, window_length=7):
    symbol = symbol.replace('/', '#')
    price = get_price(data_path, start, end, symbol, period, measurement)

    df = pd.DataFrame(data={'price': price})
    rsi_values = rsi(df, 'price', window_length)
    rsi_values = rsi_values.dropna()
    return rsi_values['rsi'].to_numpy()


class StrategyParser():
    def __init__(self, start, end, symbol, data_path, lines_settings, values_settings, trade_settings, verbose=False):
        '''
        timeframe(int): how long in minutes a candle period is
        file_paths: must be in order from least to greatest timestamp
        '''
        self.lines_settings = lines_settings
        self.values_settings = values_settings
        self.trade_settings = trade_settings
        self.verbose = verbose

        self.values_by_name = {}
        self.lines_by_name = {}
        self.trade_by_name = {}

        self.start = start
        self.end = end
        self.symbol = symbol
        self.data_path = data_path

    # def get_file_pa
    # def find_files():

    def get_values(self, name, value_type, **settings):
        # print(value_type,settings)
        if value_type == 'price':
            self.values_by_name[name] = get_price(self.data_path, self.start, self.end, self.symbol, **settings)
        if value_type == 'rsi':
            self.values_by_name[name] = get_rsi(self.data_path, self.start, self.end, self.symbol, **settings)

    def recursive_line(self, line_setting=None, name=None):
        '''

        line_setting: can be a dict that defines lines or a string of the lines name
        '''
        _id = ''

        if isinstance(line_setting, str):
            # print(line_setting)
            name = line_setting
            line_setting = self.lines_settings[line_setting]

        if name is not None and name in self.lines_by_name:
            if self.verbose:
                print(f'PRECOMPUTED:{name}')
            return self.lines_by_name[name], line_setting
        if self.verbose:
            print(f'START:{name}')

        if 'line_point_filter' in line_setting:
            if self.verbose:
                print('\tline_point_filter')

            left, line_setting_left = self.recursive_line(line_setting=line_setting['line_point_filter']['left'])
            right, line_setting_right = self.recursive_line(line_setting=line_setting['line_point_filter']['right'])

            # converts the left and right lines to have comparable peroid indecies
            lcm = np.lcm(line_setting_left['period'], line_setting_right['period'])

            left_multiplier = lcm // line_setting_right['period']
            right_multiplier = lcm // line_setting_left['period']

            left = timeframe_multiplier(left, left_multiplier)
            right = timeframe_multiplier(right, right_multiplier)

            if isinstance(line_setting['line_point_filter']['filter_type'], int):
                left, right = line_point_filter(left,
                                                right,
                                                filter_type=line_setting['line_point_filter']['filter_type'],
                                                allowed_offset=line_setting['line_point_filter']['allowed_offset'])

            else:
                left, right = line_point_filter(left,
                                                right,
                                                filter_type=line_setting['line_point_filter']['filter_type'][1],
                                                allowed_offset=line_setting['line_point_filter']['allowed_offset'][1])

                left, right = line_point_filter(left,
                                                right,
                                                filter_type=line_setting['line_point_filter']['filter_type'][0],
                                                allowed_offset=line_setting['line_point_filter']['allowed_offset'][0])

            # converts the desired line back to original peroid indecies
            # if line_setting['line_point_filter']['keep'] == 'last':

            if line_setting['line_point_filter']['keep'] == 'right':
                lines = timeframe_divider(right, right_multiplier)
                line_setting['period'] = line_setting_right['period']

            if line_setting['line_point_filter']['keep'] == 'left':
                lines = timeframe_divider(left, left_multiplier)
                line_setting['period'] = line_setting_left['period']
            else:
                pass

        if 'values' in line_setting:
            if self.verbose:
                print('\tvalues')
            values = self.values_by_name[line_setting['values']]
            line_setting['period'] = self.values_settings[line_setting['values']]['period']

        if 'lines' in line_setting:
            if self.verbose:
                print('\tlines')
            lines, old_line_setting = self.recursive_line(line_setting=line_setting['lines'])
            line_setting['period'] = old_line_setting['period']
            line_setting['_print_delay'] = old_line_setting['_print_delay']

        if 'extrema_lines' in line_setting:
            if self.verbose:
                print('\textrema_lines')
            lines = extrema_lines(values, **line_setting['extrema_lines'])
            line_setting['_print_delay'] = 2 * line_setting['period']

        if 'slope_filter' in line_setting:
            if self.verbose:
                print('\tslope_filter')
            lines = slope_filter(values, lines, **line_setting['slope_filter'])

        if 'concativity_filter' in line_setting:
            if self.verbose:
                print('\tconcativity_filter')
            lines = concativity_filter(values, lines, **line_setting['concativity_filter'])

        if name is not None:
            self.lines_by_name[name] = lines
        if self.verbose:
            print(f'END:{name}')
        return lines, line_setting

    def trade(self, trade_setting, name):
        if self.verbose:
            print(f'START:{name}')
        self.trade_by_name[name] = {}
        trade = self.trade_by_name[name]
        if 'trail_stop' in trade_setting:

            if self.verbose:
                print('\ttrail_stop')

            values = self.values_by_name[trade_setting['trail_stop']['values']]
            lines = self.lines_by_name[trade_setting['trail_stop']['lines']]

            s = {key: trade_setting['trail_stop'][key] for key in trade_setting['trail_stop'] if (key != 'lines' and key != 'values')}

            trade['entry_x'], trade['entry_y'], trade['exit_x'], trade['exit_y'], trade['ratio'] = trail_stop(values, lines, **s)
        if self.verbose:
            print(f'END:{name}')

    def run(self):
        for values_setting in self.values_settings:
            self.get_values(values_setting, **self.values_settings[values_setting])

        for name in self.lines_settings.keys():
            self.recursive_line(self.lines_settings[name], name)

        for name in self.trade_settings.keys():
            self.trade(self.trade_settings[name], name)

    def get_stats(self):
        stats = {}
        for name in self.trade_by_name:
            if len(self.trade_by_name[name]['ratio']) == 0:
                stats[name] = None
            else:
                try:
                    stats[name] = {}
                    stats[name]['avg_ratio'] = np.mean(self.trade_by_name[name]['ratio'])
                    stats[name]['trade_count'] = len(self.trade_by_name[name]['ratio'])
                    stats[name]['sum_log_ratio'] = np.sum(np.log(self.trade_by_name[name]['ratio']))
                    stats[name]['avg_log_ratio'] = np.mean(np.log(self.trade_by_name[name]['ratio']))
                except RuntimeWarning:
                    print(self.trade_by_name)

        return stats

    def print_stats(self):
        stats = self.get_stats()
        for name in stats:
            print(stats[name])

    def plot(self, values_name, lines_name=None, trade_name=None):
        values = self.values_by_name[values_name]

        data = [
            go.Scattergl(
                y=values, mode="markers+lines", name=values_name
            ),
        ]

        if lines_name is not None:
            lines = self.lines_by_name[lines_name]
            x_plot_lines = []
            y_plot_lines = []
            for line in lines:
                x_plot_lines += [line[0], line[1], None]
                y_plot_lines += [values[line[0]], values[line[1]], None]

            data += [
                go.Scattergl(
                    x=x_plot_lines, y=y_plot_lines, mode="markers", name=lines_name + ' markers'
                ),
                go.Scattergl(
                    x=x_plot_lines, y=y_plot_lines, mode="markers+lines", name=lines_name
                ),
            ]

        if trade_name is not None:
            x = []
            y = []
            trade = self.trade_by_name[trade_name]
            entry_x, entry_y, exit_x, exit_y = trade['entry_x'], trade['entry_y'], trade['exit_x'], trade['exit_y']
            for i in range(0, len(entry_x)):
                x += [entry_x[i], exit_x[i], None]
                y += [entry_y[i], exit_y[i], None]

            data += [
                go.Scattergl(
                    x=x_plot_lines, y=y_plot_lines, mode="markers+lines", name=lines_name
                ),
            ]

        fig = go.Figure(
            data=data
        )
        fig.show()
