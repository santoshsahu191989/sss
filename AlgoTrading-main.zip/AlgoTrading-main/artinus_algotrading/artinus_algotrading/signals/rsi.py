import pandas as pd
pd.options.mode.chained_assignment = None

def ema(df, col, window_length):
    return df[col].ewm(span=window_length, adjust=False).mean()

def rsi(df_in, price, window_length: int = 7):

    df = df_in.copy(deep=True)
    # Calculate Price Differences using the column specified as price.
    df['diff'] = df[price].diff(1)

    # Calculate Avg. Gains/Losses
    df['gain'] = df['diff'].clip(lower=0)
    df['loss'] = df['diff'].clip(upper=0).abs()

    # Get initial Averages
    df['ema_gain'] = ema(df, col='gain', window_length=window_length)
    df['ema_loss'] = ema(df, col='loss', window_length=window_length)

    # Calculate Average Gains
    for i, row in enumerate(df['ema_gain'].iloc[window_length+1:]):
        df['ema_gain'].iloc[i + window_length + 1] =\
            (df['ema_gain'].iloc[i + window_length] *
             (window_length - 1) +
             df['gain'].iloc[i + window_length + 1])\
            / window_length

    # Calculate Average Losses
    for i, row in enumerate(df['ema_loss'].iloc[window_length+1:]):
        df['ema_loss'].iloc[i + window_length + 1] =\
            (df['ema_loss'].iloc[i + window_length] *
             (window_length - 1) +
             df['loss'].iloc[i + window_length + 1])\
            / window_length

    # Calculate RS Values
    df['rs'] = df['ema_gain'] / df['ema_loss']

    # Calculate RSI
    df['rsi'] = 100 - (100 / (1.0 + df['rs']))
    df_in['rsi'] = df['rsi']
    return df_in
