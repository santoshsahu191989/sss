from scipy import signal
import numpy as np

def zig(y, freq = 0.1, extrema_radius = 2):


    # filter y with low pass filter
    b, a = signal.butter(2, freq, fs=1, btype='low', analog=False)
    y_filt = signal.filtfilt(b, a, y)
    deriv = y_filt[1:]-y_filt[:-1]

    # find lowest value extrema_radius away from all troughs in the filtered signal 
    troughs = np.where((deriv[1:]>0) &(deriv[:-1]<=0))[0]+1  # +1 is to account for data that goes missing when doing [1:] 

    trough_lows = []
    for n in troughs:
        trough_index, trough_price = None, None
        for index, price in enumerate(y[max(n-extrema_radius,0):min(extrema_radius+n+1,len(y))], n-extrema_radius):
            if trough_index is None or trough_price > price:
                trough_index, trough_price = index, price

        trough_lows.append(trough_index)

    # find higest value extrema_radius away from all peaks in the filtered signal 
    peaks = np.where((deriv[1:]<0) &(deriv[:-1]>=0))[0]+1  # +1 is to account for data that goes missing when doing [1:] 

    peak_highs = []
    for n in peaks:
        peak_index, peak_price = None, None
        for index, price in enumerate(y[max(n-extrema_radius,0):min(n+1+extrema_radius,len(y))], n-extrema_radius):
            if peak_index is None or peak_price < price:
                peak_index, peak_price = index, price
        peak_highs.append(peak_index)



    zig = trough_lows+peak_highs
    zig.sort()
    
    return zig, peak_highs, trough_lows