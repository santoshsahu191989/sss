# AlgoTrading
Investigating technical trading methods
