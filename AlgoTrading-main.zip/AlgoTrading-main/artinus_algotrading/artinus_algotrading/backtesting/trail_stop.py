import numpy as np


def trail_stop(values, lines, trail_threshold, line_index = 1, short = False, period_delay = 0, **_):
    entry_x = []
    entry_y = []
    exit_x = []
    exit_y = []
        
    for line in lines:
        
        start_x = line[line_index] + period_delay
        if short:
            trail = values[start_x] + trail_threshold
        else:
            trail = values[start_x] - trail_threshold
            
        entry_x.append(start_x)
        entry_y.append(values[start_x])

        found_exit = False
        for trail_index in range(start_x,len(values)):
            value = values[trail_index]
            if short:
                trail = min(trail,value)
                if value > trail+trail_threshold:
                    exit_x.append(trail_index)
                    exit_y.append(value)
                    found_exit = True
                    break
            else:
                trail = max(trail,value)
                if value < trail-trail_threshold:
                    exit_x.append(trail_index)
                    exit_y.append(value)
                    found_exit = True
                    break
        # Exits posistion at end of week.
        if not found_exit:
            exit_x.append(line_index)
            exit_y.append(value)
            
    if short:
        ratio = np.divide(entry_y, exit_y)
        
    else:
        ratio = np.divide(exit_y, entry_y)
    
    # TODO: remove this temp fix. This shouldent be here but somehow there are sometimes 0's in the ratio which cant happen
    if any(ratio ==0.): 
        # print('WARNING: Trade Ratio of 0 fixed')
        ratio[ratio == 0] = 1
        
    return entry_x, entry_y, exit_x, exit_y, ratio